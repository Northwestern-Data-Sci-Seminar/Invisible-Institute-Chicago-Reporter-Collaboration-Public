create function exec_parameterized_cmd(selection text, join_predicate text)
    returns TABLE(id integer, gender character varying, race character varying, appointed_date date, rank character varying, active character varying, birth_year integer, first_name character varying, last_name character varying, tags character varying[], middle_initial character varying, suffix_name character varying, resignation_date date, complaint_percentile numeric, middle_initial2 character varying, civilian_allegation_percentile numeric, honorable_mention_percentile numeric, internal_allegation_percentile numeric, trr_percentile numeric, allegation_count integer, sustained_count integer, civilian_compliment_count integer, current_badge character varying, current_salary integer, discipline_count integer, honorable_mention_count integer, last_unit_id integer, major_award_count integer, trr_count integer, unsustained_count integer, has_unique_name boolean, created_at timestamp with time zone, updated_at timestamp with time zone)
    language plpgsql
as
$$
BEGIN
	RETURN QUERY EXECUTE 'SELECT * FROM data_officer o JOIN ('
		|| 'SELECT $1  FROM data_officer GROUP BY  $1 HAVING COUNT(*) = 1) d '
		|| ' ON $2';
END
$$;

alter function exec_parameterized_cmd(text, text) owner to cpdb;

