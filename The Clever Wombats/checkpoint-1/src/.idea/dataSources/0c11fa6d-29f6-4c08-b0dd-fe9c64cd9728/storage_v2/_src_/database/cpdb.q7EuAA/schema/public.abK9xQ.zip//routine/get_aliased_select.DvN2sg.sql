create function get_aliased_select(fields text[], alias_ text) returns text
    language plpgsql
as
$$
BEGIN
	RETURN  alias_ || '.' || array_to_string(fields, ', ' || alias_ || '.');
END
$$;

alter function get_aliased_select(text[], text) owner to cpdb;

