create function get_select(fields text[]) returns text
    language plpgsql
as
$$
BEGIN
	RETURN  array_to_string(fields, ', ');
END
$$;

alter function get_select(text[]) owner to cpdb;

