create function _st_dwithinuncached(geography, geography, double precision) returns boolean
    immutable
    language sql
as
$$
SELECT $1 OPERATOR(public.&&) public._ST_Expand($2,$3) AND $2 OPERATOR(public.&&) public._ST_Expand($1,$3) AND public._ST_DWithinUnCached($1, $2, $3, true)
$$;

alter function _st_dwithinuncached(geography, geography, double precision) owner to rdsadmin;

