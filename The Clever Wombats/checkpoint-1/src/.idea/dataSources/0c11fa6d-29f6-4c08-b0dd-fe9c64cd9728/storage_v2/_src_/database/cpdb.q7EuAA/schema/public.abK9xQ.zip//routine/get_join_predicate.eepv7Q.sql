create function get_join_predicate(fields text[], lhs_alias text, rhs_alias text) returns text
    language plpgsql
as
$$
DECLARE
	join_predicate text;
	field text;
BEGIN
      join_predicate = '';
      FOREACH field IN ARRAY fields LOOP
      	      join_predicate = join_predicate ||  ' AND ' ||  lhs_alias || '.' || field || ' = ' || rhs_alias || '.' || field;
      END LOOP;

   -- chop off the first ' AND ', 1-indexed
   RETURN ' ' ||  substring(join_predicate FROM 6);
	
END
$$;

alter function get_join_predicate(text[], text, text) owner to cpdb;

